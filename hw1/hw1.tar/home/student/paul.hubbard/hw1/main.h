//main.h file for homework one for CS 161
#include <iostream>
#include <iomanip>
#include <cmath>
#include <limits>
#include <sstream>
